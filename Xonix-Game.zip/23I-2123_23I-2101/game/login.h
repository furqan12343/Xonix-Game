#ifndef LOGIN_H
#define LOGIN_H

#include <string>
bool isValidUser(const std::string& username, const std::string& password);
bool loginpage();

#endif

